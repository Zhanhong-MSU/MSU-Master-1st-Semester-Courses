#!/bin/bash

# Script Function: Clean up build artifacts
# Usage: ./clean.sh

echo "Cleaning up build directory..."

if [ -d "build" ]; then
    rm -rf build
    echo "Build directory 'build/' has been removed."
else
    echo "Build directory 'build/' does not exist. Nothing to clean."
fi

echo "Clean complete."
