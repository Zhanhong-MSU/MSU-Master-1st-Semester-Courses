# OpenMP Array Sum Project

This is an OpenMP-based parallel array summation program designed for Ubuntu/Linux environments.

## Project Structure

*   `src/main.cpp`: Core source code.
*   `CMakeLists.txt`: CMake build configuration file.
*   `build_and_run.sh`: Script to automatically install dependencies, compile, and run.
*   `clean.sh`: Script to clean up build artifacts.

## How to Run on Any Ubuntu System

This project does not depend on any specific IDE (like VS Code). It can be run as long as there is a terminal in the system.

### Method 1: Using the Automated Script (Recommended)

We provide a script that automatically detects and installs the compiler (g++), build tool (CMake), and OpenMP library, then compiles and runs the program.

1.  Open a terminal.
2.  Enter the project directory.
3.  Run the following commands:

```bash
chmod +x build_and_run.sh
./build_and_run.sh
```

### Method 2: Manual Compilation

If you prefer to control the compilation process manually, follow these steps:

    **Install Dependencies**:
    ```bash
    sudo apt-get update
    sudo apt-get install -y build-essential cmake
    # libomp-dev might be needed for Clang, but GCC usually includes OpenMP support.
    # sudo apt-get install -y libomp-dev 
    ```

2.  **Build the Project**:
    ```bash
    mkdir -p build
    cd build
    cmake ..
    make
    ```

3.  **Run the Program**:
    The program now supports automatic thread detection.

    *   **Auto-detect mode** (Uses all available cores):
        ```bash
        ./array_sum
        ```

    *   **Manual mode** (Specify thread count, e.g., 8 threads):
        ```bash
        ./array_sum 8
        ```

    *   **Full control** (Specify threads and array size):
        ```bash
        # Usage: ./array_sum [num_threads] [array_size]
        ./array_sum 8 100000000
        ```

## Cleaning Up

To remove build files and start fresh:
```bash
./clean.sh
```

## Portability Notes

*   This project uses the **CMake** build system, which is the industry standard for C++ cross-platform development.
*   The `.vscode` folder only contains auxiliary configurations for the editor (such as code highlighting). **Deleting it will not affect the compilation and running of the program**.
*   As long as the target machine has a standard C++ compiler and OpenMP support installed, this project can run.
