# OpenMP Array Sum - Parallel Computing Homework

**Student ID**: 58

## 1. Project Overview

This project is an OpenMP-based parallel array summation program that demonstrates how to use the `#pragma omp critical` directive for multi-threaded accumulation while avoiding common performance pitfalls.

### Assignment Parameters (Calculated from Student ID 58)

| Parameter | Formula | Result |
|-----------|---------|--------|
| Task Target | `(58 % 4) + 1 = 3` | Sum of Array |
| Parallel Method | `((58 / 4) % 5) + 1 = 5` | Use `critical` directive |
| Data Type | `(58 / 20) + 1 = 3` | `long long` (64-bit integer) |

---

## 2. Project Structure

```
PPSC-homework-No.5-58/
├── src/
│   └── main.cpp      # Core source code (with detailed comments)
├── Makefile          # Build script
└── README.md         # This documentation file
```

---

## 3. Build and Run

### 3.1 Requirements

- **Operating System**: Linux / macOS / Windows (WSL)
- **Compiler**: g++ (with C++11 and OpenMP support)
- **Dependencies**: None (OpenMP is typically built into GCC)

### 3.2 Build

```bash
make
```

### 3.3 Run

```bash
# Auto-detect thread count, use default 100 million elements
./array_sum

# Specify 4 threads
./array_sum 4

# Specify 8 threads + 500 million elements
./array_sum 8 500000000
```

### 3.4 Clean

```bash
make clean
```

### 3.5 Help

```bash
make help
```

---

## 4. Technical Implementation

### 4.1 Problem Background

In a multi-threaded environment, multiple threads simultaneously modifying the same shared variable (such as the accumulator `sum`) can cause a **Race Condition**, leading to incorrect results.

For example, if two threads execute `sum += value` simultaneously:
1. Thread A reads `sum = 100`
2. Thread B reads `sum = 100`
3. Thread A writes `sum = 100 + 5 = 105`
4. Thread B writes `sum = 100 + 3 = 103` ← **Overwrites Thread A's result!**

Final `sum = 103`, but the correct answer should be `108`.

### 4.2 Solution: Critical Directive

OpenMP's `#pragma omp critical` directive creates a **critical section**, ensuring only one thread can enter the code block at a time:

```cpp
#pragma omp critical
{
    sum += local_value;  // Only one thread can execute this line
}
```

### 4.3 Performance Pitfall and Optimization

#### ❌ Wrong Approach: Lock on Every Addition

```cpp
#pragma omp parallel for
for (int i = 0; i < N; i++) {
    #pragma omp critical
    sum += data[i];  // Lock acquired N times!
}
```

**Problem**: If the array has 100 million elements, the critical section is entered 100 million times. Threads spend most of their time waiting for the lock, completely defeating the purpose of parallelization. In practice, this approach is **10-50x slower** than single-threaded execution.

#### ✅ Correct Approach: Local Aggregation

```cpp
#pragma omp parallel
{
    long long local_sum = 0;  // Each thread's private variable

    #pragma omp for
    for (int i = 0; i < N; i++) {
        local_sum += data[i];  // No lock needed, each thread works independently
    }

    #pragma omp critical
    {
        global_sum += local_sum;  // Lock only when merging final results
    }
}
```

**Advantage**: Lock acquisition count drops from $O(N)$ to $O(num\_threads)$. With 8 threads processing 100 million elements, the lock is acquired only 8 times instead of 100 million times.

### 4.4 Key OpenMP Directives

| Directive | Purpose |
|-----------|---------|
| `#pragma omp parallel` | Start parallel region, create thread team |
| `#pragma omp for` | Distribute loop iterations among threads |
| `#pragma omp critical` | Create critical section for mutual exclusion |
| `omp_get_max_threads()` | Get maximum number of threads supported |
| `omp_set_num_threads(n)` | Set number of threads for parallel region |

---

## 5. Sample Output

```
==================================================
Student ID: 58
Task: Sum of Array (Parallel Computing)
Method: OpenMP with 'critical' (Local Aggregation)
Data Type: long long int (64-bit integer)
==================================================
Array Size: 100000000
--------------------------------------------------
Generating 100000000 random integers...
Data generation complete.
--------------------------------------------------
Running Serial Version (1 Thread)...
Serial Result:   5050128596
Serial Time:     62.345 ms
--------------------------------------------------
Running Parallel Version (8 Threads) [Auto-detected]...
Parallel Result: 5050128596
Parallel Time:   12.567 ms
--------------------------------------------------
Validation: SUCCESS (Results match)
Speedup: 4.96x
==================================================
```

---

## 6. Performance Analysis

### 6.1 Speedup Formula

$$
\text{Speedup} = \frac{T_{serial}}{T_{parallel}}
$$

- **Speedup > 1**: Parallel version is faster
- **Speedup < 1**: Parallel version is slower (overhead exceeds benefit)
- **Speedup ≈ num_threads**: Near-ideal linear speedup

### 6.2 Factors Affecting Performance

| Factor | Description |
|--------|-------------|
| **Memory Bandwidth** | Array summation is a "memory-bound" task. CPU computation speed far exceeds memory read speed. Multiple threads reading simultaneously may saturate memory bandwidth. |
| **Core Count** | More cores lead to higher theoretical speedup, but limited by memory bandwidth. |
| **Data Size** | With small data sizes, thread creation/destruction overhead may cancel out parallel benefits. |
| **Compiler Optimization** | Using `-O3` optimization significantly improves performance and ensures fair comparison. |

### 6.3 Amdahl's Law

$$
\text{Speedup}_{max} = \frac{1}{(1-P) + \frac{P}{N}}
$$

Where:
- $P$: Fraction of code that can be parallelized
- $N$: Number of processors

For this program, nearly 100% of the computation (the summation loop) can be parallelized, so the theoretical speedup approaches $N$. However, it is limited by memory bandwidth and synchronization overhead in practice.

---

## 7. Project Significance

1. **Understand Parallel Programming Fundamentals**: Master basic OpenMP usage through practice.
2. **Recognize Race Conditions**: Understand why shared variables need synchronization protection.
3. **Avoid Performance Pitfalls**: Learn optimization techniques like "Local Aggregation".
4. **Performance Analysis Skills**: Learn to evaluate parallel program efficiency using speedup metrics.

---

**Author**: Student 58  
**Date**: November 2025
