#include <iostream>
#include <vector>
#include <random>
#include <chrono>
#include <omp.h>
#include <numeric>
#include <iomanip>

// Function to generate random data
std::vector<long long> generate_data(size_t size) {
    std::cout << "Generating " << size << " random integers..." << std::endl;
    std::vector<long long> data(size);
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<long long> dis(1, 100); // Random numbers between 1 and 100

    for (size_t i = 0; i < size; ++i) {
        data[i] = dis(gen);
    }
    return data;
}

// Serial Sum Implementation
long long serial_sum(const std::vector<long long>& data) {
    long long sum = 0;
    for (const auto& val : data) {
        sum += val;
    }
    return sum;
}

// Parallel Sum Implementation using 'critical'
long long parallel_sum(const std::vector<long long>& data, int num_threads) {
    long long global_sum = 0;

    // Set the number of threads
    omp_set_num_threads(num_threads);

    #pragma omp parallel
    {
        long long local_sum = 0;

        // Distribute loop iterations among threads
        // Each thread calculates a partial sum in its private 'local_sum' variable.
        // This is the "Local Aggregation" strategy to avoid the performance trap of 
        // entering a critical section for every single addition.
        #pragma omp for
        for (size_t i = 0; i < data.size(); ++i) {
            local_sum += data[i];
        }

        // Critical section to safely update the global sum with the thread's local sum.
        // This only happens once per thread, not once per element.
        #pragma omp critical
        {
            global_sum += local_sum;
        }
    }

    return global_sum;
}

int main(int argc, char* argv[]) {
    // Print Student ID and Task Description
    std::cout << "==================================================" << std::endl;
    std::cout << "Student ID: 58" << std::endl;
    std::cout << "Task: Sum of Array (Parallel)" << std::endl;
    std::cout << "Method: OpenMP with 'critical' (Local Aggregation)" << std::endl;
    std::cout << "Data Type: long long int (64-bit)" << std::endl;
    std::cout << "==================================================" << std::endl;

    // Default configuration
    size_t array_size = 100000000; // Increased to 100 million elements to offset thread overhead
    
    // Default to all available threads on the system (VPS/PC)
    // omp_get_max_threads() typically returns the number of logical processors
    int num_threads = omp_get_max_threads();

    // Parse command line arguments
    if (argc > 1) {
        int input_threads = std::atoi(argv[1]);
        if (input_threads > 0) {
            num_threads = input_threads;
        } else {
            std::cout << "Warning: Invalid thread count specified. Using system default." << std::endl;
        }
    }
    if (argc > 2) {
        array_size = std::stoull(argv[2]);
    }

    std::cout << "Array Size: " << array_size << std::endl;
    std::cout << "--------------------------------------------------" << std::endl;

    // 1. Generate Data
    auto data = generate_data(array_size);
    std::cout << "Data generation complete." << std::endl;
    std::cout << "--------------------------------------------------" << std::endl;

    // 2. Serial Execution (Baseline - Always 1 Thread)
    std::cout << "Running Serial Version (1 Thread)..." << std::endl;
    auto start_serial = std::chrono::high_resolution_clock::now();
    long long result_serial = serial_sum(data);
    auto end_serial = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> duration_serial = end_serial - start_serial;

    std::cout << "Serial Result:   " << result_serial << std::endl;
    std::cout << "Serial Time:     " << std::fixed << std::setprecision(3) << duration_serial.count() * 1000 << " ms" << std::endl;
    std::cout << "--------------------------------------------------" << std::endl;

    // 3. Parallel Execution (OpenMP - N Threads)
    std::cout << "Running Parallel Version (" << num_threads << " Threads)...";
    if (argc <= 1) std::cout << " [Auto-detected]";
    std::cout << std::endl;

    auto start_parallel = std::chrono::high_resolution_clock::now();
    long long result_parallel = parallel_sum(data, num_threads);
    auto end_parallel = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> duration_parallel = end_parallel - start_parallel;

    std::cout << "Parallel Result: " << result_parallel << std::endl;
    std::cout << "Parallel Time:   " << std::fixed << std::setprecision(3) << duration_parallel.count() * 1000 << " ms" << std::endl;

    // 4. Validation and Analysis
    std::cout << "--------------------------------------------------" << std::endl;
    if (result_serial == result_parallel) {
        std::cout << "Validation: SUCCESS (Results match)" << std::endl;
    } else {
        std::cout << "Validation: FAILED (Results do not match)" << std::endl;
    }

    double speedup = duration_serial.count() / duration_parallel.count();
    std::cout << "Speedup: " << speedup << "x" << std::endl;

    return 0;
}
