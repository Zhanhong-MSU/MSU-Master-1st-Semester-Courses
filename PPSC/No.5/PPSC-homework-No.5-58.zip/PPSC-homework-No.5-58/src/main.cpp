/**
 * ============================================================================
 * OpenMP Array Sum - Parallel Computing Homework
 * ============================================================================
 * 
 * Student ID: 58
 * 
 * Task Assignment (Calculated from Student ID):
 *   - Task Target:    (58 % 4) + 1 = 3  -> Sum of Array
 *   - Method:         ((58 / 4) % 5) + 1 = 5  -> Use 'critical' directive
 *   - Data Type:      (58 / 20) + 1 = 3  -> long long int (64-bit)
 * 
 * ============================================================================
 * Technical Implementation
 * ============================================================================
 * 
 * This program demonstrates the use of OpenMP's 'critical' directive for
 * parallel array summation. The key challenge is to avoid the "lock contention"
 * performance trap while still using critical sections.
 * 
 * WRONG Approach (Performance Trap):
 *   #pragma omp parallel for
 *   for (int i = 0; i < N; i++) {
 *       #pragma omp critical
 *       sum += data[i];  // Lock acquired N times! Extremely slow.
 *   }
 * 
 * CORRECT Approach (Local Aggregation):
 *   #pragma omp parallel
 *   {
 *       long long local_sum = 0;  // Each thread has its own private sum
 *       #pragma omp for
 *       for (int i = 0; i < N; i++) {
 *           local_sum += data[i];  // No lock needed here
 *       }
 *       #pragma omp critical
 *       global_sum += local_sum;  // Lock acquired only once per thread!
 *   }
 * 
 * This reduces lock contention from O(N) to O(num_threads).
 * 
 * ============================================================================
 */

#include <iostream>   // For console I/O (cout, endl)
#include <vector>     // For dynamic array (std::vector)
#include <random>     // For random number generation
#include <chrono>     // For high-precision timing
#include <omp.h>      // OpenMP header for parallel programming
#include <iomanip>    // For output formatting (setprecision)
#include <cstdlib>    // For atoi, stoull

// ============================================================================
// Function: generate_data
// ============================================================================
// Purpose: Generate a vector filled with random 64-bit integers.
// 
// Parameters:
//   - size: The number of elements to generate.
// 
// Returns:
//   A std::vector<long long> containing random numbers in range [1, 100].
// 
// Note: Using long long (64-bit) to prevent overflow when summing large arrays.
//       For example, 100 million elements with max value 100 could sum to
//       10 billion, which exceeds the 32-bit integer limit (~2.1 billion).
// ============================================================================
std::vector<long long> generate_data(size_t size) {
    std::cout << "Generating " << size << " random integers..." << std::endl;
    
    std::vector<long long> data(size);
    
    // Use Mersenne Twister engine for high-quality random numbers
    std::random_device rd;          // Seed from hardware entropy
    std::mt19937 gen(rd());         // Mersenne Twister PRNG
    std::uniform_int_distribution<long long> dis(1, 100);  // Range: [1, 100]

    for (size_t i = 0; i < size; ++i) {
        data[i] = dis(gen);
    }
    
    return data;
}

// ============================================================================
// Function: serial_sum
// ============================================================================
// Purpose: Calculate the sum of all elements in a vector using a single thread.
//          This serves as the BASELINE for performance comparison.
// 
// Parameters:
//   - data: Reference to the vector of long long integers.
// 
// Returns:
//   The sum of all elements as a long long integer.
// 
// Complexity: O(N) where N is the size of the array.
// ============================================================================
long long serial_sum(const std::vector<long long>& data) {
    long long sum = 0;
    
    // Simple sequential iteration - no parallelism
    for (size_t i = 0; i < data.size(); ++i) {
        sum += data[i];
    }
    
    return sum;
}

// ============================================================================
// Function: parallel_sum
// ============================================================================
// Purpose: Calculate the sum of all elements using OpenMP parallelization
//          with the 'critical' directive for thread synchronization.
// 
// Parameters:
//   - data: Reference to the vector of long long integers.
//   - num_threads: Number of threads to use for parallel execution.
// 
// Returns:
//   The sum of all elements as a long long integer.
// 
// Implementation Strategy: LOCAL AGGREGATION
//   Step 1: Each thread computes a partial sum independently (no locking).
//   Step 2: After all iterations, each thread adds its partial sum to the
//           global sum inside a critical section (minimal lock contention).
// 
// Why not use 'reduction' or 'atomic'?
//   - This homework specifically requires using 'critical' directive.
//   - 'reduction' would be more efficient but doesn't meet the requirement.
//   - 'atomic' is also not allowed per the assignment specification.
// ============================================================================
long long parallel_sum(const std::vector<long long>& data, int num_threads) {
    long long global_sum = 0;

    // Set the number of threads for the parallel region
    omp_set_num_threads(num_threads);

    // Begin parallel region - each thread executes this block
    #pragma omp parallel
    {
        // ====================================================================
        // STEP 1: Local Aggregation
        // ====================================================================
        // Each thread has its own 'local_sum' variable (private by default
        // since it's declared inside the parallel region).
        // This eliminates the need for synchronization during the loop.
        // ====================================================================
        long long local_sum = 0;

        // Distribute loop iterations among threads using static scheduling
        // Thread 0 might get indices [0, N/4), Thread 1 gets [N/4, N/2), etc.
        #pragma omp for
        for (size_t i = 0; i < data.size(); ++i) {
            local_sum += data[i];  // No synchronization needed here!
        }

        // ====================================================================
        // STEP 2: Critical Section - Safe Global Update
        // ====================================================================
        // Only ONE thread can execute this block at a time.
        // Since we only enter here once per thread (not once per element),
        // the lock contention is minimal: O(num_threads) instead of O(N).
        // ====================================================================
        #pragma omp critical
        {
            global_sum += local_sum;
        }
        // After exiting the critical section, the lock is released and
        // another waiting thread can enter.
    }
    // Implicit barrier: all threads synchronize before returning

    return global_sum;
}

// ============================================================================
// Main Function
// ============================================================================
int main(int argc, char* argv[]) {
    // ========================================================================
    // Print Program Header with Student Information
    // ========================================================================
    std::cout << "==================================================" << std::endl;
    std::cout << "Student ID: 58" << std::endl;
    std::cout << "Task: Sum of Array (Parallel Computing)" << std::endl;
    std::cout << "Method: OpenMP with 'critical' (Local Aggregation)" << std::endl;
    std::cout << "Data Type: long long int (64-bit integer)" << std::endl;
    std::cout << "==================================================" << std::endl;

    // ========================================================================
    // Configuration with Defaults
    // ========================================================================
    // Default array size: 100 million elements
    // This is large enough to demonstrate parallel speedup on modern CPUs.
    size_t array_size = 100000000;
    
    // Default thread count: Use all available logical processors
    // omp_get_max_threads() returns the maximum number of threads that
    // would be used if a parallel region was started without explicit setting.
    int num_threads = omp_get_max_threads();

    // ========================================================================
    // Command Line Argument Parsing
    // ========================================================================
    // Usage: ./array_sum [num_threads] [array_size]
    //   - num_threads: Optional. Number of threads for parallel version.
    //   - array_size:  Optional. Number of elements in the array.
    // ========================================================================
    if (argc > 1) {
        int input_threads = std::atoi(argv[1]);
        if (input_threads > 0) {
            num_threads = input_threads;
        } else {
            std::cout << "Warning: Invalid thread count. Using default." << std::endl;
        }
    }
    if (argc > 2) {
        array_size = std::stoull(argv[2]);
    }

    std::cout << "Array Size: " << array_size << std::endl;
    std::cout << "--------------------------------------------------" << std::endl;

    // ========================================================================
    // PHASE 1: Data Generation
    // ========================================================================
    auto data = generate_data(array_size);
    std::cout << "Data generation complete." << std::endl;
    std::cout << "--------------------------------------------------" << std::endl;

    // ========================================================================
    // PHASE 2: Serial Execution (Baseline)
    // ========================================================================
    // Run the single-threaded version first to establish a baseline.
    // This result will be used to verify correctness and calculate speedup.
    // ========================================================================
    std::cout << "Running Serial Version (1 Thread)..." << std::endl;
    
    auto start_serial = std::chrono::high_resolution_clock::now();
    long long result_serial = serial_sum(data);
    auto end_serial = std::chrono::high_resolution_clock::now();
    
    std::chrono::duration<double> duration_serial = end_serial - start_serial;

    std::cout << "Serial Result:   " << result_serial << std::endl;
    std::cout << "Serial Time:     " << std::fixed << std::setprecision(3) 
              << duration_serial.count() * 1000 << " ms" << std::endl;
    std::cout << "--------------------------------------------------" << std::endl;

    // ========================================================================
    // PHASE 3: Parallel Execution (OpenMP with Critical)
    // ========================================================================
    // Run the multi-threaded version using the specified number of threads.
    // ========================================================================
    std::cout << "Running Parallel Version (" << num_threads << " Threads)";
    if (argc <= 1) std::cout << " [Auto-detected]";
    std::cout << "..." << std::endl;

    auto start_parallel = std::chrono::high_resolution_clock::now();
    long long result_parallel = parallel_sum(data, num_threads);
    auto end_parallel = std::chrono::high_resolution_clock::now();
    
    std::chrono::duration<double> duration_parallel = end_parallel - start_parallel;

    std::cout << "Parallel Result: " << result_parallel << std::endl;
    std::cout << "Parallel Time:   " << std::fixed << std::setprecision(3) 
              << duration_parallel.count() * 1000 << " ms" << std::endl;

    // ========================================================================
    // PHASE 4: Validation and Performance Analysis
    // ========================================================================
    // Compare results to ensure parallel version is correct.
    // Calculate speedup factor: Serial Time / Parallel Time
    // ========================================================================
    std::cout << "--------------------------------------------------" << std::endl;
    
    if (result_serial == result_parallel) {
        std::cout << "Validation: SUCCESS (Results match)" << std::endl;
    } else {
        std::cout << "Validation: FAILED (Results do not match!)" << std::endl;
        std::cout << "  Expected: " << result_serial << std::endl;
        std::cout << "  Got:      " << result_parallel << std::endl;
    }

    // Speedup = T_serial / T_parallel
    // Speedup > 1 means parallel version is faster
    // Speedup < 1 means parallel version is slower (overhead exceeds benefit)
    double speedup = duration_serial.count() / duration_parallel.count();
    std::cout << "Speedup: " << std::fixed << std::setprecision(2) 
              << speedup << "x" << std::endl;

    std::cout << "==================================================" << std::endl;

    return 0;
}
