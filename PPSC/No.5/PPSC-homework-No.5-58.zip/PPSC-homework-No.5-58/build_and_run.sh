#!/bin/bash

# Script Function: Automatically install dependencies, compile, and run the program on Ubuntu
# Usage: ./build_and_run.sh

set -e # Stop immediately on error

echo ">>> [1/3] Checking and installing dependencies..."
# Check if g++ is installed
if ! command -v g++ &> /dev/null; then
    echo "Installing g++..."
    sudo apt-get update
    sudo apt-get install -y build-essential
fi

# Check if cmake is installed
if ! command -v cmake &> /dev/null; then
    echo "Installing cmake..."
    sudo apt-get update
    sudo apt-get install -y cmake
fi

# Check if OpenMP library is installed
# On Ubuntu with GCC, OpenMP is usually included.
# We will skip explicit installation of libomp-dev as it caused issues and is often unnecessary for GCC.
# echo "Ensuring OpenMP library is installed..."
# sudo apt-get install -y libomp-dev

echo ">>> [2/3] Compiling project..."
# Clean old build directory (optional)
rm -rf build
mkdir -p build
cd build

# Run CMake configuration
cmake ..

# Compile
make

echo ">>> [3/3] Running program..."
# Run the generated executable
# Auto-detect mode: Uses all available cores on the system
./array_sum
